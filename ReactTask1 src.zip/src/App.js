import Indu from "./Components/Color";

function App() {
  return (
    <div>
        <Indu></Indu>
    </div>
  )
}

export default App;
