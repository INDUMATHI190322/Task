import { Module } from '@nestjs/common';
import { OccupationService } from './occupation/occupation.service';
import { OccupationController } from './occupation/occupation.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { occupation } from './occupations.entity';
import { Contact } from 'src/contacts/contact.entity';
@Module({
    imports: [
      TypeOrmModule.forFeature([occupation,Contact]),
    ],
  

  providers: [OccupationService],
  controllers: [OccupationController]
})
export class OccupationModule {}
