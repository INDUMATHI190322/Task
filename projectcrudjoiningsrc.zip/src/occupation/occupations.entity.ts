import { Entity, Column, PrimaryGeneratedColumn,ManyToOne, JoinColumn } from 'typeorm';
import { Contact } from 'src/contacts/contact.entity';
@Entity()
export class occupation {
    @PrimaryGeneratedColumn()
    id: number;
    
    @Column()
    occupation:string;

    @ManyToOne(()=>Contact,(contact)=>contact.occupation)
    @JoinColumn({name:'id'})
    contact:Contact;
    
}