import { Controller,Get } from '@nestjs/common';
import { occupation } from '../occupations.entity';
import { OccupationService } from './occupation.service';
import { Post,Put, Delete, Body, Param } from  '@nestjs/common';


@Controller('occupation')
export class OccupationController {
    
    constructor(private occupationService: OccupationService){}

    @Get()
    index(): Promise<occupation[]> {
      return this.occupationService.findAll();
    } 
    @Post('create')
    async create(@Body() occupationData: occupation): Promise<any> {
      return this.occupationService.create(occupationData);
    }   
    @Put(':id/update')
    async update(@Param('id') id, @Body() occupationData: occupation): Promise<any> {
        occupationData.id = Number(id);
        console.log('Update #' + occupationData.id)
        return this.occupationService.update(occupationData);
    }  
    @Delete(':id/delete')
    async delete(@Param('id') id): Promise<any> {
      return this.occupationService.delete(id);
    } 
    //@Get('join')
    //getoccupation() {
      //return this.occupationService.getoccupation();
    //} 
}
