import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { occupation } from '../occupations.entity';
import { UpdateResult, DeleteResult } from  'typeorm';
import { Contact } from 'src/contacts/contact.entity';



@Injectable()
export class OccupationService{
    constructor(
        @InjectRepository(occupation)
        private occupationRepository: Repository<occupation>,
        @InjectRepository(Contact)
        private contactsRepository: Repository<Contact>,
    ) { }
    async  findAll(): Promise<occupation[]> {
        return await this.occupationRepository.find();
    }

    async  create(occupation:occupation): Promise<occupation> {
        return await this.occupationRepository.save(occupation);
    }

    async update(occupation: occupation): Promise<UpdateResult> {
        return await this.occupationRepository.update(occupation.id, occupation);
    }

    async delete(id): Promise<DeleteResult> {
        return await this.occupationRepository.delete(id);
    }
//         async getoccupation(): Promise<occupation[]> {
//             return this.occupationRepository.find({ relations: ['Contact'] });
          
    
// }


}
