import { Module } from '@nestjs/common';
import { ContactsService } from './contacts/contacts.service';
import { ContactsController } from './contacts/contacts.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Contact } from './contact.entity';
import { occupation } from 'src/occupation/occupations.entity';
import { OccupationService } from 'src/occupation/occupation/occupation.service';
import { OccupationController } from 'src/occupation/occupation/occupation.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([Contact,occupation]),
  ],
  
  providers: [ContactsService],
  controllers: [ContactsController]
})
export class ContactsModule {}