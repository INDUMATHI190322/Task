import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { Contact } from '../contact.entity';
import { UpdateResult, DeleteResult } from  'typeorm';
import { occupation } from 'src/occupation/occupations.entity';
import { OccupationController } from 'src/occupation/occupation/occupation.controller';
import { QueryBuilder } from 'typeorm';


@Injectable()
export class ContactsService {
    constructor(
        @InjectRepository(Contact)
        private contactRepository: Repository<Contact>
    ) { }
    // async getContactWithOccupations(id : number) {
    //     const contactWithOccupations = await this.contactRepository.find({
    //       where: { id },
    //       relations: ['occupation'], // Ensure occupations are loaded
    //     });

    // console.log(); 
    // return Contact;
    // }
    // async getContactWithOccupation(id: number) {
    //     return await this.contactRepository
    //       .createQueryBuilder('contact')
    //       .leftJoinAndSelect('contact.occupation', 'occupation')
    //       .where('contact.id = :id', { id }) // Filter by contact.id = 2
    //       .getMany(); // Use getOne() if you're expecting a single result
    //   }
    
        

async  findAll(): Promise<Contact[]> {
    
    return await this.contactRepository.find();
}

async  create(contact: Contact): Promise<Contact> {
    

    return await this.contactRepository.save(contact);
}

async update(contact: Contact): Promise<UpdateResult> {
    
    return await this.contactRepository.update(contact.id, contact);
}

async delete(id): Promise<DeleteResult> {

    return await this.contactRepository.delete(id);
}
// async getcontacts(): Promise<Contact[]> {
//     return this.contactRepository.find({ relations: ['occupation'] });
// }
// async getoccupation(): Promise<Contact[]> {
//     return this.contactRepository.find({ relations: ['occupation']});
// }
async getoccupation(): Promise<any> {
    const contactsWithoccupation=await this.contactRepository
    
      .createQueryBuilder('contact')
      .innerJoinAndSelect('contact.occupation', 'occupation')
      .getMany();
      return contactsWithoccupation;
    
}

}