import { Entity, Column, PrimaryGeneratedColumn,OneToMany } from 'typeorm';
import { occupation } from 'src/occupation/occupations.entity';

@Entity()
export class Contact {
    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    firstName: string;

    @Column()
    lastName: string;

    @Column()
    email: string;

    @Column()
    phone: string;

    @Column()
    city: string;

    @Column()
    country: string;

    @OneToMany(()=> occupation,(occupation) => occupation.contact)
    occupation: occupation[];
    
}