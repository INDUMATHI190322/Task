
import Depent from"./Components/Dependentdropdown";

function App() {
  return (
    <div>
        
        <Depent></Depent>
    </div>
  )
}

export default App;
